import React, { useState, useEffect } from 'react';
import PageLayout from '../../components/page/PageLayout';
import PageHeader from '../../components/page/PageHeader';
import Tabs from '../../components/page/Tabs';
import FilterBar from '../../components/page/FilterBar';
import DataTable from '../../components/page/DataTable';
import EmptyState from '../../components/page/EmptyState';
import Loader from '../../components/page/Loader';
import { 
    FiAlertCircle, FiClock, FiDollarSign, FiDownload, 
    FiUsers, FiCalendar, FiPhone, FiCheckCircle 
} from 'react-icons/fi';
import apiClient from '../../api/apiClient';
import { toast } from 'react-toastify';

export default function Reports() {
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState('Expiring Plans');
    const [searchTerm, setSearchTerm] = useState('');
    
    // Date Filters
    const [filterStartDate, setFilterStartDate] = useState('');
    const [filterEndDate, setFilterEndDate] = useState('');

    const [activePlans, setActivePlans] = useState([]);
    const [transactions, setTransactions] = useState([]);
    const [staffAttendance, setStaffAttendance] = useState([]);

    useEffect(() => {
        const fetchReportData = async () => {
            setLoading(true);
            try {
                const todayStr = new Date().toISOString().split('T')[0];
                const [activePlansRes, txRes, staffAttRes] = await Promise.all([
                    apiClient.get('/member-memberships/active').catch(() => ({ data: [] })),
                    apiClient.get('/members/transactions/all').catch(() => ({ data: [] })),
                    apiClient.get(`/attendance/daily-sheet?date=${todayStr}&type=staff`).catch(() => ({ data: [] }))
                ]);

                setActivePlans(activePlansRes.data || []);
                setTransactions(txRes.data || []);
                setStaffAttendance(staffAttRes.data || []);
            } catch (err) {
                toast.error("Failed to load report data");
            } finally {
                setLoading(false);
            }
        };

        fetchReportData();
    }, []);

    // CSV Export Helper
    const exportCSV = (data, filename) => {
        if (!data || !data.length) {
            toast.info("No data available to export");
            return;
        }
        const headers = Object.keys(data[0]).join(',');
        const rows = data.map(row => Object.values(row).map(v => `"${v ?? ''}"`).join(','));
        const csvContent = "data:text/csv;charset=utf-8," + [headers, ...rows].join('\n');
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", `${filename}_${new Date().toISOString().split('T')[0]}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        toast.success(`Exported ${filename} report!`);
    };

    // Filter Logic
    const filterBySearchAndDate = (items, getDate, getSearchStr) => {
        return items.filter(item => {
            if (filterStartDate || filterEndDate) {
                const itemDate = new Date(getDate(item));
                itemDate.setHours(0,0,0,0);
                if (filterStartDate) {
                    const start = new Date(filterStartDate);
                    start.setHours(0,0,0,0);
                    if (itemDate < start) return false;
                }
                if (filterEndDate) {
                    const end = new Date(filterEndDate);
                    end.setHours(23,59,59,999);
                    if (itemDate > end) return false;
                }
            }
            if (searchTerm) {
                return getSearchStr(item).toLowerCase().includes(searchTerm.toLowerCase());
            }
            return true;
        });
    };

    if (loading) return <Loader text="Loading reports..." />;

    // 1. Expiring Plans (Expiring in next 30 days)
    const today = new Date();
    const thirtyDaysLater = new Date();
    thirtyDaysLater.setDate(today.getDate() + 30);

    const expiringMemberships = activePlans.filter(p => {
        if (!p.endDate) return false;
        const end = new Date(p.endDate);
        return end >= today && end <= thirtyDaysLater;
    });

    // 2. Pending Dues (Members with pending amount > 0)
    const pendingDuesMemberships = activePlans.filter(p => Number(p.pendingAmount) > 0);

    // Tab view setup
    let columns = [];
    let filteredData = [];
    let renderRow = null;
    let emptyIcon = <FiAlertCircle size={48} />;
    let emptyTitle = "No records found";

    if (activeTab === 'Expiring Plans') {
        columns = [
            { label: 'Member Name' },
            { label: 'Plan Name' },
            { label: 'Expiry Date' },
            { label: 'Status / Days Left' }
        ];
        filteredData = filterBySearchAndDate(
            expiringMemberships,
            p => p.endDate,
            p => `${p.memberId?.firstName || ''} ${p.memberId?.lastName || ''} ${p.membershipPlanId?.name || ''}`
        );
        renderRow = (p) => {
            const daysLeft = Math.ceil((new Date(p.endDate) - today) / (1000 * 60 * 60 * 24));
            return (
                <tr key={p._id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-bold text-slate-800 text-sm">
                        {p.memberId?.firstName} {p.memberId?.lastName || ''}
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-600 text-xs">
                        {p.membershipPlanId?.name || 'Custom Plan'}
                    </td>
                    <td className="py-3 px-4 text-xs font-bold text-rose-600">
                        {new Date(p.endDate).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-4">
                        <span className="inline-flex px-2.5 py-1 rounded bg-amber-50 text-amber-700 border border-amber-200 text-xs font-bold">
                            {daysLeft <= 0 ? 'Expiring Today' : `${daysLeft} Days Left`}
                        </span>
                    </td>
                </tr>
            );
        };
        emptyIcon = <FiCalendar size={48} />;
        emptyTitle = "No plans expiring soon";
    } else if (activeTab === 'Pending Dues') {
        columns = [
            { label: 'Member Name' },
            { label: 'Plan Name' },
            { label: 'Total Amount' },
            { label: 'Pending Dues' }
        ];
        filteredData = filterBySearchAndDate(
            pendingDuesMemberships,
            p => p.createdAt || p.startDate,
            p => `${p.memberId?.firstName || ''} ${p.memberId?.lastName || ''} ${p.membershipPlanId?.name || ''}`
        );
        renderRow = (p) => (
            <tr key={p._id} className="hover:bg-slate-50 transition-colors">
                <td className="py-3 px-4 font-bold text-slate-800 text-sm">
                    {p.memberId?.firstName} {p.memberId?.lastName || ''}
                </td>
                <td className="py-3 px-4 font-medium text-slate-600 text-xs">
                    {p.membershipPlanId?.name || 'Standard Plan'}
                </td>
                <td className="py-3 px-4 text-xs font-semibold text-slate-600">
                    ₹{Number(p.totalAmount || 0).toLocaleString()}
                </td>
                <td className="py-3 px-4 font-black text-rose-600 text-sm">
                    ₹{Number(p.pendingAmount || 0).toLocaleString()}
                </td>
            </tr>
        );
        emptyIcon = <FiAlertCircle size={48} />;
        emptyTitle = "No pending dues found";
    } else if (activeTab === 'Daily Collections') {
        columns = [
            { label: 'Member Name' },
            { label: 'Amount Collected' },
            { label: 'Payment Mode' },
            { label: 'Date & Time' }
        ];
        filteredData = filterBySearchAndDate(
            transactions,
            t => t.paymentDate || t.createdAt,
            t => `${t.memberName || t.memberId?.name || ''} ${t.paymentMode || ''}`
        );
        renderRow = (tx) => (
            <tr key={tx._id} className="hover:bg-slate-50 transition-colors">
                <td className="py-3 px-4 font-bold text-slate-800 text-sm">
                    {tx.memberName || tx.memberId?.name || 'Gym Member'}
                </td>
                <td className="py-3 px-4 font-black text-emerald-600 text-sm">
                    ₹{Number(tx.amountPaid || 0).toLocaleString()}
                </td>
                <td className="py-3 px-4">
                    <span className="inline-flex px-2 py-1 bg-slate-100 text-slate-700 text-xs font-bold rounded uppercase">
                        {tx.paymentMode || 'Cash'}
                    </span>
                </td>
                <td className="py-3 px-4 text-xs font-medium text-slate-500">
                    {new Date(tx.paymentDate || tx.createdAt).toLocaleDateString()}
                </td>
            </tr>
        );
        emptyIcon = <FiDollarSign size={48} />;
        emptyTitle = "No collection records found";
    } else if (activeTab === 'Staff Working Hours') {
        columns = [
            { label: 'Staff / Trainer Name' },
            { label: 'Shift Status' },
            { label: 'Check In' },
            { label: 'Check Out' }
        ];
        filteredData = filterBySearchAndDate(
            staffAttendance,
            s => s.attendance?.date || new Date(),
            s => `${s.user?.name || ''} ${s.user?.phone || ''}`
        );
        renderRow = (item) => (
            <tr key={item.user._id} className="hover:bg-slate-50 transition-colors">
                <td className="py-3 px-4 font-bold text-slate-800 text-sm">{item.user.name}</td>
                <td className="py-3 px-4">
                    <span className={`inline-flex px-2.5 py-1 rounded text-xs font-bold uppercase ${item.attendance?.checkOutTime ? 'bg-blue-50 text-blue-700 border border-blue-200' : item.attendance?.checkInTime ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-slate-100 text-slate-600'}`}>
                        {item.attendance?.checkOutTime ? 'Completed' : item.attendance?.checkInTime ? 'On Duty' : 'Not Checked In'}
                    </span>
                </td>
                <td className="py-3 px-4 text-xs font-medium text-slate-600">
                    {item.attendance?.checkInTime ? new Date(item.attendance.checkInTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true }) : '--:--'}
                </td>
                <td className="py-3 px-4 text-xs font-medium text-slate-600">
                    {item.attendance?.checkOutTime ? new Date(item.attendance.checkOutTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true }) : '--:--'}
                </td>
            </tr>
        );
        emptyIcon = <FiClock size={48} />;
        emptyTitle = "No staff attendance records found";
    }

    return (
        <PageLayout>
            <PageHeader 
                title="Business Reports & Analytics" 
                subtitle="Actionable report intelligence: Expiring plans, dues, collections and trainer shifts."
                action={
                    <button 
                        onClick={() => {
                            if (activeTab === 'Expiring Plans') exportCSV(filteredData.map(p => ({ Member: `${p.memberId?.firstName} ${p.memberId?.lastName || ''}`, Plan: p.membershipPlanId?.name || 'Custom', ExpiryDate: new Date(p.endDate).toLocaleDateString() })), 'Expiring_Plans_Report');
                            else if (activeTab === 'Pending Dues') exportCSV(filteredData.map(p => ({ Member: `${p.memberId?.firstName} ${p.memberId?.lastName || ''}`, TotalAmount: p.totalAmount, PendingDues: p.pendingAmount })), 'Pending_Dues_Report');
                            else if (activeTab === 'Daily Collections') exportCSV(filteredData.map(t => ({ Member: t.memberName || t.memberId?.name || 'N/A', Amount: t.amountPaid, Mode: t.paymentMode, Date: new Date(t.paymentDate || t.createdAt).toLocaleDateString() })), 'Daily_Collections_Report');
                            else exportCSV(filteredData.map(s => ({ Staff: s.user?.name, CheckIn: s.attendance?.checkInTime || 'N/A', CheckOut: s.attendance?.checkOutTime || 'N/A' })), 'Staff_Shifts_Report');
                        }}
                        className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors shadow-sm"
                    >
                        <FiDownload className="text-base" /> Export CSV
                    </button>
                }
            />

            <Tabs 
                tabs={['Expiring Plans', 'Pending Dues', 'Daily Collections', 'Staff Working Hours']}
                activeTab={activeTab}
                onTabChange={(tab) => {
                    setActiveTab(tab);
                    setSearchTerm('');
                    setFilterStartDate('');
                    setFilterEndDate('');
                }}
            />

            <FilterBar 
                searchTerm={searchTerm} 
                onSearchChange={setSearchTerm} 
                searchPlaceholder={`Search ${activeTab.toLowerCase()}...`}
            >
                <div className="flex items-center bg-white border border-slate-200 rounded-lg shadow-sm h-10 px-2 transition-all focus-within:border-emerald-500 focus-within:ring-1 focus-within:ring-emerald-500 w-full sm:w-auto">
                    <input 
                        type="date" 
                        value={filterStartDate}
                        onChange={(e) => setFilterStartDate(e.target.value)}
                        className="text-sm focus:outline-none text-slate-600 bg-transparent w-full sm:w-auto"
                        title="From Date"
                    />
                    <span className="text-slate-300 mx-2 font-medium text-xs">TO</span>
                    <input 
                        type="date" 
                        value={filterEndDate}
                        onChange={(e) => setFilterEndDate(e.target.value)}
                        className="text-sm focus:outline-none text-slate-600 bg-transparent w-full sm:w-auto"
                        title="To Date"
                    />
                </div>
            </FilterBar>

            {filteredData.length > 0 ? (
                <DataTable 
                    columns={columns} 
                    data={filteredData} 
                    loading={loading}
                    emptyMessage={`No ${activeTab.toLowerCase()} records found.`}
                    renderRow={renderRow} 
                />
            ) : (
                <div className="flex-1 overflow-y-auto">
                    <EmptyState 
                        icon={emptyIcon}
                        title={searchTerm ? `No ${activeTab.toLowerCase()} records match search` : emptyTitle}
                        description={searchTerm ? `No results for "${searchTerm}"` : `There are no ${activeTab.toLowerCase()} records available.`}
                    />
                </div>
            )}
        </PageLayout>
    );
}
